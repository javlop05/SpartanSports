package transfer;

public enum TipoUsuario {
	ADMINISTRADOR, CLIENTE;
}
