package transfer;

public enum TipoAbono {
	MENSUAL,TRIMESTRAL,ANUAL;
}
