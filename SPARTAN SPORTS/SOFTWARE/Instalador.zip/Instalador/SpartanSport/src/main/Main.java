package main;

import Ventanas.*;;

public class Main {

	public static void main(String[] args) {
		VentanaPrincipal obj = new VentanaPrincipal();
		obj.setVisible(true);

	}

}
